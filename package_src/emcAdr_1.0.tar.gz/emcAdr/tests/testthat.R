library(testthat)
library(emcAdr)

test_check("emcAdr")
