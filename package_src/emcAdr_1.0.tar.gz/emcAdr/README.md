# Evolutionary Markov Chain for Adverse Drug Reaction

R package implementing an Evolutionary Monte-Carlo Markov Chain algorithm (an adaptation of Metropolis-Hastings). This package is designed to be used with medical data, especially with patients using medications.

*Supervisor : Mr. Birmele Etienne*
