.onAttach <- function(libname,pkgname){
  packageStartupMessage("Welcome to this Emc algorithm package ! If you notice any unexpected behavior of a method, please bring it to my attention (<jules.bangard@etu.unistra.fr>).")
}